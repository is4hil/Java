import java.util.Scanner;

public class Arrays {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Number of Elements ");
		int num=scan.nextInt();
		int ar[]=new int[num];
		System.out.println("Enter the Numbers: ");
		for(int i=0;i<ar.length;i++)
		{
			ar[i]=scan.nextInt();
		}
	    int positive=0,negative=0;
		for(int i=0;i<ar.length;i++)
		{
			if(ar[i]<1)
				negative++;
			else
				positive++;
		}
		System.out.println("Number of Positive Number is: "+positive+" And Number of Negative Number is: "+negative);
		scan.close();
	}
}
