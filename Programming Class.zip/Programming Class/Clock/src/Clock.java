/*nextShort(); -->To capture SHORT DATA
 *nextInt(); -->To capture INTEGER VALUE
 *nextDouble(); -->To capture floating point data
 *next();--> To capture the Screen 
 *nextLine(); -->To capture string 
 *nextFloat();
 *nextLong();
 */

import java.util.Scanner;
public class Clock {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Input Hour :");
		int hh=scan.nextInt();
		//int hh=5;                                    
		System.out.println("Input Minute");
		int min=scan.nextInt();
		//int min=18;
		double hangle=hh*30+min*0.5;
		double mangle=min*6;
		double angle=0.0;
		if (hangle>mangle)
			angle=hangle-mangle;
		else
			angle=mangle-hangle;
		if(angle>180)
			angle=360-angle;
		System.out.println("lEAST Angle between "+hh+" hours and "+min+" minutes is :"+angle);
		System.out.println("lEAST Angle between "+hh+" hours and "+min+" minutes is :"+(360-angle));
		scan.close();
		//close.scan();
	}
}
