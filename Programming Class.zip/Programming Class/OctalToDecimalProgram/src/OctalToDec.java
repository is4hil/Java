import java.util.Scanner;


public class OctalToDec {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Octal Number To Convert: ");
		int num=scan.nextInt();
		int res=octToDec(num);
		System.out.println("The Equivalent Decimal Number of Octal Number "+num+" is -->"+res);
		scan.close();

	}
	static int octToDec(int n)
	{
		int sum=0,p=0;
		while(n!=0)
		{
			int r=n%10;
			sum=sum+r*pow(8,p);
			p++;
			n=n/10;
		}
		return sum;
	}


	static int pow(int n,int p)
	{
		int pw=1;
		while(p>0)
		{
			pw=pw*n;  
			p--;
		}
		return pw;
	}

}
