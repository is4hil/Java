import java.util.Scanner;


public class DecToHex {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Decimal Number To Convert: ");
		int num=scan.nextInt();
		String hex=decToHex(num);
		System.out.println("The Equivalent Hexa Decimal Number of Decimal Number "+num+" is --> 42 "+hex);
		scan.close();
	}
	static String decToHex(int n)
	{
		String hex="";
		while(n>0)
		{
			int r=n%16;
			if(r<10)
				hex=r+hex;
			else
				hex=(char)(r+55)+hex;
			n=n/16;
		}
		return hex;
	}
}