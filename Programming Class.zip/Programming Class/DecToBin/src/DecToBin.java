import java.util.Scanner;


public class DecToBin {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Decimal Number To Convert: ");
		int num=scan.nextInt();
		String dec=decToBin(num);
		System.out.println("The Equivalent Binary Number of Octal Number "+num+" is -->"+dec);
		scan.close();
}
   static String decToBin(int n)
   {
	   String bin="";
	   while(n>0)
	   {
		   int r=n%2;
		   bin=r+bin;
		   n=n/2;
	   }
	   return bin;
   }
}