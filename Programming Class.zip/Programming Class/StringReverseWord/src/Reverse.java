import java.util.Scanner;

public class Reverse {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the Sentences : ");
	 	String st=scan.nextLine();
	    char ch[]=st.toCharArray();
	    String rs="";
	    for (int i = 0; i < ch.length; i++) {
	    	int si=i;
	    	while(i<ch.length && ch[i]!=' ')
	    	{
	    		i++;
	    	}
	    	int ei=i-1;
	    	while(ei>=si)
	    	{
	    		rs=rs+ch[ei];
	    		ei--;
	    	}
	    	if(i<ch.length)
	    		rs=rs+ch[i];
		}
	    
	    System.out.print(rs+" ");
	    scan.close();
	}
	
	
}
