import java.util.Scanner;


public class Binary {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter The Binary Number To Convert: ");
	int num=scan.nextInt();
	int res=binToDec(num);
	System.out.println("The Equivalent Decimal Number of Octal Number "+num+" is -->"+res);
	scan.close();
	
}
static int binToDec(int n)
{
int sum=0,p=0;
while(n!=0)
{
int r=n%10;
sum=sum+r*pow(2,p);
p++;
n=n/10;
}
return sum;
}


static int pow(int n,int p)
{
int pw=1;
while(p>0)
{
pw=pw*n;
p--;
}
return pw;
}






}
