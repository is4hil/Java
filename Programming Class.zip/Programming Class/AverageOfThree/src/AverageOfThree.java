//Write a Java program that takes three numbers as input to calculate and print the average of the numbers.
import java.util.Scanner;
public class AverageOfThree {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter 3 numbers with space in between");
		double a =scan.nextDouble();
		double b = scan.nextDouble();
		double c = scan.nextDouble();
		double avg=(a+b+c)/3;
		System.out.println("The Average of Two Number is: "+avg);
		scan.close();
	}
}
