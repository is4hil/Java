
public class Arrays {
	public static void main(String[] args) {
		int ar[] = { 1, 2, 3, 4, 5, 6, 7 };
		int countArray[] = new int[2];
		for (int i = 0; i < ar.length; i++) {
			countArray[ar[i] % 2]++;

		}
		System.out.println("Number of Even Number in array is: " + countArray[0]);
		System.out.println("Number of Odd Number in array is: " + countArray[1]);
	}
}
