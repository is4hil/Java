//Write a Java program to print the area and perimeter of a rectangle
import java.util.Scanner;
public class RectangleArea {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Length: ");
		double l=scan.nextDouble();
		System.out.println("Enter the Breadth: ");
		double b=scan.nextDouble();
		//final double PI=3.14;
		double area=l*b;
		double perimeter=2*l*b;
		System.out.println("Area of Rectangle is: "+area);
		System.out.println("Perimeter of Rectangle is: "+perimeter);
		scan.close();
	}
}
