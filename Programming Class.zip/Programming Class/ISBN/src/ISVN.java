import java.util.Scanner;

public class ISVN {
public static void main(String[] args) {
	System.out.println("Enter the ISBN number");
	Scanner scan=new Scanner(System.in);
			String s=scan.next();
			if(s.length()!=10)
			{
				System.out.println("Not Valid ISBN");
				return;
			}
			
			int sum=0;
			for (int i = 0; i < s.length(); i++) 
			{
			 char ch=s.charAt(i);
			 if(ch<'0'&&ch>'9')
			 {
				 System.out.println("It is not valid IsBN");
				 return;
			 }
			 sum=sum+(ch-48)*(s.length()-i);
				 
			}
			if(sum%11==0)
				System.out.println("Valid ISBN");
			else
				System.out.println("Invalid");
			

			
			//1861972717
			
}
}
