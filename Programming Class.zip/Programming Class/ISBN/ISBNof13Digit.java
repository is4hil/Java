import java.util.Scanner;

public class ISBNof13Digit {
public static void main(String[] args) {
	System.out.println("Enter the ISBN number");
	Scanner scan=new Scanner(System.in);
			String s=scan.next();
			if(s.length()!=13)
			{
				System.out.println("Not Valid ISBN");
				return;
			}
			
			int sum=0;
			for (int i = 0; i < s.length()-1; i++) 
			{
			 
				char ch[]=s.toCharArray();
			
			 if(ch[i]<'0'&&ch[i]>'9')
			 {
				 System.out.println("It is not valid IsBN");
				 return;
			 }
			 
			if(ch[i]%2==0)
			{
				ch[i]=ch[i]*1;
				int sum1=sum1+ch[i];
			}
			
			else if(ch[i]%2!=0)
			{
				ch[i]=ch[i]*3;
				int sum2=sum2+ch[i];
			}
			 sum=sum1+sum2;
			 int rem=sum%10;
			if(rem==0)
				System.out.println("Valid");

			else
				int temp=10-r;
			if(ch[ch.length]==temp)
				System.out.println("Valid");
}
}
