/*Write a Java program to convert a binary number to decimal number. 
Input:
Input a binary number: 100
Output:
Decimal Number: 4
*/
import java.util.Scanner;
public class BinaryToDecimal {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Decimal Number: ");
		int b=scan.nextInt();
		System.out.printf("%d",b);
		scan.close();

	}

}