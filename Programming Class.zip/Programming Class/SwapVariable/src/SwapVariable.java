//Write a Java program to swap two variables
public class SwapVariable {
	int x=10;
	int y=20;
	int tmp;
	void swap()
	{
		tmp=x;
		x=y;
		y=tmp;
		System.out.println("x="+x);
		System.out.println("y="+y);
	}
	public static void main(String[] args) {
	SwapVariable s=new SwapVariable();
	s.swap();
}
}
