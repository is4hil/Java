
public class Arrays {
public static void main(String[] args) 
{
	int ar[]= {1,2,3,4,5,6};
	int rs[]=revArray(ar);
	dispArray(rs);
}
	 static int[] revArray(int ar[]) {
		 for(int i=0;i<ar.length/2;i++)
		{
			int temp=ar[i];
				ar[i]=ar[ar.length-1-i];
				ar[ar.length-1-i]=temp;
		
		}
		 return ar;
	}
	 
	 static void dispArray(int ar[]) {
			for(int i=0;i<ar.length;i++)
			{
				System.out.print(ar[i]+" ");
			}
		}
}
