
public class BigOfTwo {

	int getBiggest(int a,int b)
	{
		if(a>b)
			return a;
		else 
			return b;
	}
	public static void main(String[] args) {
		BigOfTwo big=new BigOfTwo();
		int b1=big.getBiggest(30,40);
		System.out.println("Biggest Number is "+b1);
//56,43,34
		int b2=big.getBiggest(big.getBiggest(56,43),34);
		System.out.println("Biggest of 3 is "+b2);
		//56,77,88,13
		int b3=big.getBiggest(big.getBiggest(56,77),big.getBiggest(88,13));
		System.out.println("Biggest of 3 is "+b3);
	}
}
