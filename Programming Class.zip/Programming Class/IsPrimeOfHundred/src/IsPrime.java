
public class IsPrime {
	public static void main(String[] args) {
		int count=0,sum=0;
		for(int n=1;n<=100;n++)
		{
			boolean rs=isPrime(n);
			if(rs)
			{
				System.out.println(n+" is Prime");
				count++;
				sum=sum+n;
				
			}
		}
		System.out.println("Number of Prime Number is :"+count);
		System.out.println("Sum of Prime Number is :"+sum);
		System.out.println("Average of Prime Number is :"+sum/count);
	}

	static boolean isPrime(int n)
	{
		int i=2;
		while(i<=n/2)
		{
			if(n%i==0)
				return false;
			i++;
		}


		return true;
	}

}


