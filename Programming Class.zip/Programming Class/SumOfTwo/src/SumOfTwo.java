import java.util.Scanner;
public class SumOfTwo {
	//double sum=0;
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the 1st Number:");
		int a=scan.nextInt();
		System.out.println("Enter the 2nd Number:");
		int b=scan.nextInt();
		double sum=a+b;
		System.out.println("The Sum of Two NUmber is :"+sum);
		scan.close();
	}
}