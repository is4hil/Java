//import java.util.Scanner;

public class Practise {
	public static void main(String[] args) {
		/*int count=countNumber();
		int num=countEven();
		System.out.println(num);
		System.out.println(count);
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter The Number");
		
		int n=scan.nextInt();
		int sum=1;
		for(int i=2;i<=n;i++)
		{
			sum=sum*i;
		}
		System.out.println(sum);
		
	}
	
	
	static int countNumber()
	{    int num=123456789,count=1;
		for(int i=1;i<=num;i++)
			{

			num=num/10;
			count++;
			}
		
		return count;
	}
	static int countEven()
	{   

		int num=123456,c=0;
		for(int i=1;i<=num;i++)
			{
			 int r=num%10;
   			if(r%2==0)
			c++;
		num=num/10;
			}
		return c ;
		*/
		
		/*int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
				{
				System.out.printf(j+i-1+" ");
				}
		System.out.println();
		}
		
		
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
				{
				System.out.printf("*");
				}
		System.out.println();
		}
		
		*/
		
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=i;j++)
				{
				System.out.printf(i+j-1+" ");
				}
		System.out.println();
		}
		
		
}
}
