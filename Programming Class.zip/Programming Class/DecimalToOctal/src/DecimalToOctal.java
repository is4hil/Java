/*Write a Java program to convert a decimal number to octal number. 
 Input :
 Decimal Number: 15 
 Output
 Octal number is: 17
*/
import java.util.Scanner;
public class DecimalToOctal {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Decimal Number: ");
		int d=scan.nextInt();
		System.out.printf("%o",d);
		scan.close();

	}

}