
import java.util.Scanner;

public class Arrays {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Number of Elements ");
		int num=scan.nextInt();
		int ar[]=new int[num];
		System.out.println("Enter the Numbers: ");
		for(int i=0;i<ar.length;i++)
		{
			ar[i]=scan.nextInt();
		}
		
		
		int count=0;
		for(int i=0;i<ar.length;i++)
		{
			if(ar[i]%15==0)
			count++;	
			//System.out.println("Number of Elements that are divisible by 3 and 5 are: "+(ar[i]%15==0));
		}
		System.out.println("Number of Elements that are divisible by 3 and 5 are: "+count);
		
		
		scan.close();
	}
}
