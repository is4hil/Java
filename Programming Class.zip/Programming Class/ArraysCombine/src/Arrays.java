import java.util.Scanner;

public class Arrays {
	public static void main(String[] args) {
		System.out.println("Enter the 1st Array: ");
		int ar1[]=readArray();
		System.out.println("Enterr The 2nd Arrray: ");
		int ar2[]=readArray();
		int rs[]=combine(ar1,ar2);
		System.out.println("After combine: ");
		dispArray(rs);
	}
	 static int [] readArray()
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Number of Elements ");
		int num=scan.nextInt();
		int ar[]=new int[num];
		System.out.println("Enter the Numbers: ");
		for(int i=0;i<ar.length;i++)
		{
			ar[i]=scan.nextInt();
		}
		return ar;
	}
	
	static void dispArray(int ar[])
	{
		for(int i=0;i<ar.length;i++)
		{
			System.out.print(ar[i]+" ");
		}
		System.out.println();
	}
	
	static int []combine(int ar[],int b[])
	{
		int rs[]=new int[ar.length+b.length];
				for(int i=0;i<ar.length;i++)
				{
					rs[i]=ar[i];
				}
		for(int i=0;i<ar.length;i++)
		{
			rs[ar.length+1]=b[i];
			
		}
		return rs;
	}
	
	
}