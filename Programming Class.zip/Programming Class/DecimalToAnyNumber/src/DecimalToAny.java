class DecimalToAny{
	public static void main(String[] args) {
		String res=decimalToAny(123,2);
		System.out.println(res);
	}
	static String decimalToAny(int dec,int b)
	{
		String con="";
		while(dec>0)
		{
			int r=dec%b;
			if(r>9)
				con=(char)(r+55)+con;
			else
				con=r+con;
		dec=dec/b;
		}
		return con;
	}
}