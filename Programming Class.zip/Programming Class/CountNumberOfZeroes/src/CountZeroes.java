import java.util.Scanner;
public class CountZeroes {
	public int getEven(int num) {
		int count=0;
		do {
			int rem=num%10;
			if (rem==0) 
				count++;
			num=num/10;

		} while (num!=0);
		return count;
	}
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Number: ");
		int numb=scan.nextInt();
		CountZeroes c=new CountZeroes();
		int result=c.getEven(numb);
		System.out.println("The Number of Zeroes are:"+result);
		scan.close();
	}
}
