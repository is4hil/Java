
public class ConvertDecimalToBinary {
public static void main(String[] args) {
	decToBin(14);
	
}

public static void decToBin(int dec) 
{
	if(dec!=0)
		decToBin(dec/2);
	System.out.print(dec%2);
}
}
