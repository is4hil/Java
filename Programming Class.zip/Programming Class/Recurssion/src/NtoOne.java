
public class NtoOne {
public static void main(String[] args) {
	display(5);
}
public static void display(int n) 
{
System.out.println(n);
if(n>1)
	display(n-1);
}
}
