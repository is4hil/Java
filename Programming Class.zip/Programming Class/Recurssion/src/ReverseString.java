
public class ReverseString {
public static void main(String[] args) {
	reverse("sahil",0);
}

private static void reverse(String s,int n) 
{
if(n<s.length()-1)
	reverse(s,n+1);
System.out.print(s.charAt(n));

}


}
