
public class ConvertDecimalToHexa {
	public static void main(String[] args) {
		decToHex(10);
		
	}

	public static void decToHex(int dec) 
	{
		if(dec!=0)
			decToHex(dec/16);
		int r=dec%16;
		if(r<10)
			System.out.print(r);
		else
			System.out.print((char)(55+r));
	}
}
