
public class SearchElement {
public static void main(String[] args) {
	int a[]= {45,67,78,68};
	int in=search(a,45,0);
	if(in>=0)
	{
		System.out.println(in);
	}
	else
		System.out.println("not");
}

private static int search(int a[], int ele, int in) {
if(in>=a.length||in<0)
	return -1;
if(a[in]==ele)
	return in;
return search(a, ele, in+1);


}

}
