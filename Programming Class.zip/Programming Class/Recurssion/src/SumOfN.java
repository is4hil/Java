
public class SumOfN {
public static void main(String[] args) {
	int s=sumOfN(500);
	System.out.println(s);
}

public static int sumOfN(int n) {
	if(n==1)
	return 1;
	
	return n+sumOfN(n-1);
}

}
