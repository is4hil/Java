
public class Arrays {
public static void main(String[] args) 
{
	int ar[]= {18,27,19,26,17,16,27,15};
	int rs=nthBiggestArray(ar,4);
	
	System.out.println("Nth biggest: "+rs);
}



	 public static  int nthBiggestArray(int ar[],int n) {
		 
		 for(int i=0;i<ar.length;i++)
		{
			int bc=0;
			for (int j = 0; j < ar.length; j++) 
			{
				if(ar[j]>ar[i])
				{
					bc++;
				}
			}

		if(bc==n-1)
		
			return ar[i];
		
		
		}
		 return 0;
		 
	}
	 
	
}
