//((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5))
public class ExpressionCalculation {
public static void main(String[] args) {
	double res=((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
	double res1=4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11));
	System.out.println("The Result of Expressiois: "+res);
	System.out.println("The Result of Expressiois: "+res1);
}
}
