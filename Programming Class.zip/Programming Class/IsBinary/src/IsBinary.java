import java.util.Scanner;


public class IsBinary {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number to validate :");
		int num=scan.nextInt();
		if(isBinary(num))
			System.out.println(num+" is Binary Number");
		else
			System.out.println(num+" is not a Binary Number ");
		scan.close();
	}

	static boolean isBinary(int n)
	{
		int rem=n%10;
		if(rem==0|rem==1)
			return true;
		else 
			return false;
	}
}
