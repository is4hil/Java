//Pgm to add marks of 4 subject and display percentage,name and usn of student
import java.util.Scanner;
public class Student {
	public static void main(String[] args) {
		Scanner scan =new Scanner(System.in);
		System.out.println("Enter Student USN: ");
		String usn=scan.next();
		System.out.println("Enter Student Name: ");
		String name=scan.next();
		System.out.println(" Enter Marks of 4 Subjects: ");
		double m1=scan.nextDouble();
		double m2=scan.nextDouble();
		double m3=scan.nextDouble();
		double m4=scan.nextDouble();
		double percent=(m1+m2+m3+m4)/4.0;
		System.out.println("Percentage= "+percent);
		System.out.println("USN is :"+usn);
		System.out.println("Name is :"+name);
		if(m1>35&&m2>35&&m3>35&&m4>35)
			{
			System.out.println("Pass");
			}
		
		else
			
			{
			System.out.println("Failed");
			}
		
		scan.close();
	}

}
