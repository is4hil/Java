
public class Arrays {
public static void main(String[] args) 
{
	int ar[]= {1,2,3,4,5,6};
	int rs[]=swapArray(ar);
	dispArray(rs);
}
	 static int[] swapArray(int ar[]) {
		 for(int i=0;i<ar.length/2;i++)
		{
			int temp=ar[2*i];
			ar[2*i]=ar[2*i+1];
			ar[2*i+1]=temp;
		}
		 return ar;
	}
	 
	 static void dispArray(int ar[]) {
			for(int i=0;i<ar.length;i++)
			{
				System.out.print(ar[i]+" ");
			}
		}
}
