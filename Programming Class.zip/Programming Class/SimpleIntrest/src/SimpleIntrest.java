
public class SimpleIntrest {
public static void main(String[] args) {
	int p=5000;
	double t=5;
	double r=7.5;
	double SI= (p*t*r)/100;
	System.out.println("Simple Intrest of Principle "+p+" Time "+t+ " and Rate "+r+" is: "+SI);
}
}
