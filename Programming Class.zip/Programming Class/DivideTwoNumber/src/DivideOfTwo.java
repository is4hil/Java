import java.util.Scanner;
public class DivideOfTwo {
	
	
	public static void main(String[] args) {
	
		{	Scanner scan= new Scanner(System.in);
			System.out.println("Enter the 1st Number:");
			double a=scan.nextDouble();
			System.out.println("Enter the 2nd Number:");
			double b=scan.nextDouble();
			double result=a/b;
			System.out.println("The Result of Division of two number is:"+result);
			scan.close();
		}
	}
}

