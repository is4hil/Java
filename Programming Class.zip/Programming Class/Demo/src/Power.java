import java.util.Scanner;

public class Power {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter The Number");
	int num=scan.nextInt();
	System.out.println("Enter the index");
	int index=scan.nextInt();
	int res=pow(num,index);
	System.out.println("result is "+res);
}

static int pow(int n,int p)
{
	int pw=1;
	while(p>0)
	{
		pw=pw*n;
		p--;
	}
	return pw;
}
}
