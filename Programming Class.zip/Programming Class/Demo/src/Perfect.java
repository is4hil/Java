import java.util.Scanner;

public class Perfect {
	
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Your Number");
		int n= scan.nextInt();
		int sum=0;
		for(int i=1;i<=n/2;i++)
		{
			if(n%i==0)
				sum=sum+i;
		}
		//System.out.println(sum);
		if(sum==n)
			System.out.println("Perfect Number");
		else
			System.out.println(" Not a Perfect Number");
	scan.close();
	}

}
