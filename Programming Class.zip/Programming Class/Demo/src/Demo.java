import java.util.Random;

class Demo extends Object{
	public static void main(String[] args) {
		Random r= new Random();
		float random1=r.nextFloat();
		System.out.println(random1);
		int random2=r.nextInt(100);
		System.out.println(random2);
		
	}
}