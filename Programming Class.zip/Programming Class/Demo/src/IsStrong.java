import java.util.Scanner;

public class IsStrong {
public static void main(String[] args) {
 Scanner scan = new Scanner(System.in);
 System.out.println("Enter The Number");
 int num=scan.nextInt();
boolean res= isStrong(num);
 if(res)
 
	 System.out.println("Strong Number");
 else
	 System.out.println("Not");
}
static boolean isStrong(int num)
{
	int  temp=num;
int sum=0;
while(num!=0)
{
	int r=num%10;
	sum=sum+fact(r);
	num=num/10;
}
return sum==temp;
	
}

static int fact(int n)
{
int fact=1;
for(int i=1;i<=n;i++)
	
	{
	fact=fact*i;
	}
return fact;
}
}
