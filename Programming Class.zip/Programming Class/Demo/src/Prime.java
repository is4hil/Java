import java.util.Scanner;

class Prime{
	public static void main(String[] args) {
		int flag=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number to check");
		int num=scan.nextInt();
		if(num<=1)
			System.out.println("Not Prime number");
		for(int i=2;i<=num/2;i++)
		{
			if(num%i==0)
			{
				System.out.println("Not Prime number");
				flag=1;
				break;
			}
		}
		if(flag==0)
			System.out.println("Enterd number is prime Number");
}
	
}