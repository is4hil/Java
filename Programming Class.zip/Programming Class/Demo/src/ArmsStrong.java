import java.util.Scanner;

public class ArmsStrong extends Power{
public static void main(String[] args) {
	int count=0;
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter the Number: ");
	int num=scan.nextInt();
	boolean res=isStrong(num);
	if(res)
		System.out.println("ArmsStrong Number");
	else
		System.out.println("Not");
	
}
static boolean isStrong(int n)
{
	int getCount(int n)
}

static int getCount(int num)
{


}

}
