


public class Happy {
public static void main(String[] args) {
	int count=0;
	
	for(int i=1;i<=1000;i++)
	{
	
	if(isHappy(i))
	{
	
		//System.out.println(i+" is Happy Number");
		count++;
		
	}
	
	}
	System.out.println("Number of Happy number is :"+count);	
}
	 
	
static boolean isHappy(int num)
{
	while(num>9)
	{
		int sum=0;
		while(num!=0)
		{
			
			int r=num%10;
			sum=sum+r*r;
			num=num/10;
		}
		
		num=sum;
	}	
return num==1||num==7;

}

}
