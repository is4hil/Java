import java.util.Scanner;

public class EvenCount {
public static void main(String[] args) {
	Scanner scan =new Scanner(System.in);
	System.out.println("Enter The number");
	int num=scan.nextInt();
	int res=even(num);
	System.out.println("Even digits are : "+res);
			
}

static int even(int n)
{
	int count =0;
	while(n!=0)
	{
	int rem=n%10;
	if(rem%2==0)
	{
		//System.out.println("Even Number");
		count++;
	}
	n=n/10;
	}
	return count;

}
}