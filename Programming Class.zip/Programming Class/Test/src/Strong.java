import java.util.Scanner;

public class Strong {
public static void main(String[] args) {
	//Scanner scan=new Scanner(System.in);
	//System.out.println("Enter The Number");
	//int n=scan.nextInt();
	for(int i=1;i<=100;i++)
	{
	boolean rs=isStrong(i);
	if(rs)
	{
		System.out.println("Strong NUmber");
		System.out.println(rs);
	}
	}//else
		//System.out.println("Not A strong Number");

}
static boolean isStrong(int num)
{
	int temp=num;
	int sum=0;
	while(num!=0)
	{
	
	
	int rem=num%10;
	sum=sum+fact(rem);
	num=num/10;
	}
	return sum==temp;
}

static int fact(int n)
{
	int fact=1;
	for(int i=1;i<=n;i++)
	{
		fact=fact*i;
	}
	return fact;
}



}






