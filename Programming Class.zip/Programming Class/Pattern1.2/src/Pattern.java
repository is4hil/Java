
public class Pattern {
public static void main(String[] args) {
	int n=15;
/*for(int i=1;i<=5;i++)
	{
		for(int j=i;j<=5;j++)
			System.out.print(i+j-1+" ");
			System.out.println();
	}
System.out.println("------------------------------------------------------------------------------------------");
for(int i=1;i<=5;i++)
{
	for(int j=1;j<=i;j++)
		{
		System.out.print(j+" ");
		}
System.out.println();
}
System.out.println("------------------------------------------------------------------------------------------");
for(int i=1;i<=5;i++)
{
	for(int j=1;j<=i;j++)
		{
		System.out.print(i+" ");
		}
System.out.println();
}
System.out.println("------------------------------------------------------------------------------------------");
for(int i=1;i<=5;i++)
{
	for(int j=1;j<=i;j++)
		{
		System.out.print(j%2+" ");
		}
System.out.println();
}
System.out.println("------------------------------------------------------------------------------------------");
for(int i=1;i<=5;i++)
{
	for(int j=1;j<=i;j++)
		{
		System.out.print(j%2+" ");
		}
System.out.println();
}
System.out.println("------------------------------------------------------------------------------------------");
for(int i=1;i<=5;i++)
{
	for(int j=1;j<=i;j++)
		{
		System.out.print(i%2+" ");
		}
System.out.println();
}
System.out.println("------------------------------------------------------------------------------------------");
for(int i=1;i<=5;i++)
{
	for(int j=5;j>=i;j--)
		{
		System.out.print(j+" ");
		}
System.out.println();
}
System.out.println("------------------------------------------------------------------------------------------");

*/
/*int c=0,n=5;
for(int i=1;i<=n;i++)
{   c=c+i;
	for(int j=1;j<n-i;j++)
	{
		System.out.print("-");
	}
	for(int j=c, k=1;k<=i;j--,k++)
	{
		System.out.println(j+" ");
	}
	System.out.println();
}

	for (int i = 1; i <=n; i++) 
	{
		System.out.print("*");
	}
	System.out.println();
	for(int i=1;i<=n-2;i++)
	{
		for (int j = 1; j <= n; j++) 
		{
		 if(j==1||j==n)
		 {
			 System.out.print("*");
		 }
		 else
			 {
			 System.out.print(" ");             // 
			 }                                  // *****
		}                                       // *   *
		System.out.println();                   // *   *
	}                                           // *   *
	                                            // *****
	for (int i = 1; i <=n; i++) 
	{
		System.out.print("*");
	}
	
System.out.println("------------------------------------------------------------------------------------------");
	
	for (int i = 1; i <= n; i++)
	{
	 for (int j = 1; j <=n ; j++)
	 {
		 if( j==1||j==n||i==1||i==n)
		 System.out.print("*");
		 else
		 System.out.print(" ");
	}
	 System.out.println();
	}
System.out.println("------------------------------------------------------------------------------------------");	
	
for (int i = 1; i <= n; i++)
{
 for (int j = 1; j <=i ; j++)
 {
	
	 System.out.print("*");
	 
}
 System.out.println();
}

System.out.println("------------------------------------------------------------------------------------------");	

for (int i = n; i>=1; i--)
{
 for (int j = 1; j <=n ; j++)
 {
	if(j<i)
	 System.out.print(" ");
	else
		System.out.print("*"+" ");
}
 System.out.println();
}
for (int j = 1; j <=n ; j++)
{
	for (int i = n; i>=1; i--)

	{
		if(j<i)
		 System.out.print(" ");
		else
			System.out.print("*"+" ");
	}
System.out.println();
*/

}
}
