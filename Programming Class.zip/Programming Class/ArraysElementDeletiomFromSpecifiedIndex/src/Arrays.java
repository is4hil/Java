
public class Arrays {
public static void main(String[] args) 
{
	int ar[]= {1,2,3,4,5,6};
	int rs[]=delArray(ar,3);
	dispArray(rs);
}
	 static int[] delArray(int ar[],int index) {
		 if(index<0||index>=ar.length)
		 {
			 System.out.println("Index Out Of Bound. ");
			 System.exit(0);
		 }
		int ar1[]=new int[ar.length-1];
		 for(int i=0;i<ar1.length;i++)
		{
			if(i<index)
				ar1[i]=ar[i];
			else
				ar1[i]=ar[i+1];
		}
		 return ar1;
	}
	 
	 static void dispArray(int ar[]) {
			for(int i=0;i<ar.length;i++)
			{
				System.out.print(ar[i]+" ");
			}
		}
}
