import java.util.Scanner;
public class Arithmetic {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the 1st integer :");
		int a=scan.nextInt();
		System.out.println("Enter the 2nd integer :");
		int b=scan.nextInt();
		System.out.println("Sum is: "+(a+b));
		System.out.println("Diffrence is: " + (a-b));
		System.out.println("Product is: "+a*b);
		System.out.println("Quotient is: "+a/b);
		System.out.println("Remainder is: "+a%b);
		scan.close();
		//Arithmetic a=new Arithmetic();
		//a.display();
	}
	}

//int a=40, b=30;
	/*
void display(){
System.out.println("Sum is: "+(a+b));
System.out.println("Diffrence is: " + (a-b));
System.out.println("Product is: "+a*b);
System.out.println("Quotient is: "+a/b);
System.out.println("Temainder is: "+a%b);*/
