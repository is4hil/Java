
public class Arrays {
public static void main(String[] args) 
{
	int ar[]= {18,27,19,26,17,16,27,89,76,77,15};
	biggestArray(ar);
	
}
	 static void biggestArray(int ar[]) {
		 int fbig=ar[0],sbig=ar[1];
		 for(int i=1;i<ar.length;i++)
		{
			if(ar[i]>fbig)
			{
			sbig=fbig;
			fbig=ar[i];
			}
			else if(ar[i]>sbig&&ar[i]!=fbig)
			{
				sbig=ar[i];
			}
			
		}
		 System.out.println("First Biggest number is: "+fbig);
		System.out.println("Second Biggest Number is: "+sbig);
		 
	}
	 
}
