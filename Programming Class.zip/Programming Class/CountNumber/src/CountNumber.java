import java.util.Scanner;
class  NumberCount{
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Number:");
		long numb=scan.nextLong();
		long res=getCount(numb);
		System.out.println("The Number is: "+res);
		scan.close();
	}
	static long getCount(long n)
	{
		long c=0;
		do{
			c++;
			n=n/10;
		}
		while(n!=0);
		return c;
	}
}
