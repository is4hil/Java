/*  
 a.-5 + 8 * 6
 b. (55+9) % 9 
 c. 20 + -3*5 / 8 
 d. 5 + 15 / 3 * 2 - 8 % 3 
*/

public class Operations {

public static void main(String[] args) {
	int res1=-5+(8*6);
	int res2=(55+9)%9;
	int res3=20+((-3*5)/8);
	int res4=5+(15/(3*2))-(8%3);
	System.out.println(res1);
	System.out.println(res2);
	System.out.println(res3);
	System.out.println(res4);
}
}
