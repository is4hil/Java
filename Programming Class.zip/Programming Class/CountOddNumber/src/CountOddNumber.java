import java.util.Scanner;
public class CountOddNumber {
	int count=0;
	public int getOdd(int num) {
		int count=0;
		do {
			int rem=num%10;
			if (rem%2!=0) 
				count++;
			num=num/10;

		} while (num!=0);
		System.out.println("The Number of odd Digits are: "+count);
		return count;
	}
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Number:");
		int numb=scan.nextInt();
		CountOddNumber c=new CountOddNumber();
		c.getOdd(numb);
		scan.close();
	}
}
