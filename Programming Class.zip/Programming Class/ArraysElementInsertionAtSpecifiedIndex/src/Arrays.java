import java.util.Scanner;



public class Arrays {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the 1st Array: ");
		int ar[] =readArray();
		System.out.println("Enter the Elemrnt : ");
		int ele=scan.nextInt();
		System.out.println("Enter the Index");
		int in=scan.nextInt();
		System.out.println("Before insertion");
		dispArray(ar);
		int rs[]=insert(ar,ele,in);
		System.out.println("After insertion: ");
		dispArray(rs);
		scan.close();
	}
	 static int [] readArray()
	{
		 
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Number of Elements ");
		int num=scan.nextInt();
		int ar[]=new int[num];
		System.out.println("Enter the Numbers: ");
		for(int i=0;i<ar.length;i++)
		{
			ar[i]=scan.nextInt();
		}
		scan.close();
		return ar;
		
	}
	
	static void dispArray(int ar[])
	{
		for(int i=0;i<ar.length;i++)
		{
			System.out.print(ar[i]+" ");
		}
		System.out.println();
	}
	
	static int[] insert(int ar[],int ele,int in)
	{
		if(in<0||in>ar.length)
			{
			System.out.println("Invalid Index");
			System.exit(0);
			}
		int rs[]= new int[ar.length+1];
		for(int i=0;i<=ar.length;i++)
		{
			if( i<in)
				rs[i]=ar[i];
			else
				rs[i+1]=ar[i];
		}
		rs[in]=ele;
		return rs;
		
		}
				
	}
	
	
