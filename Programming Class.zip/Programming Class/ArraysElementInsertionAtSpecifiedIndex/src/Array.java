import java.util.Scanner;

class Array{
	static int[] readArray()
	{	
		Scanner scan =new Scanner(System.in);
		System.out.println("Enter the number of element of array: ");
		int num=scan.nextInt();
		int ar[]=new int[num];
		System.out.println("Enter the Elements of Array :");
		for(int i=0;i<ar.length;i++)
		{
			ar[i]=scan.nextInt();
		}
		
		return ar;
		
	}
	public static void main(String[] args) 
	{  
	    int ar[] = readArray();
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the inddex where you want to enter the new element: ");
		int index=scan.nextInt();
		System.out.println("Enter the new element that you want to enter: ");
		int element=scan.nextInt();
		int rs[]=insert(ar,element,index);
		dispArray(rs);
		scan.close();
	}
	
	static int[] insert(int ar[] ,int el, int in)
	{
		int ar1[]=new int[ar.length+1];
		for (int i = 0; i < ar.length; i++) {
			if(i<in)
				ar1[i]=ar[i];
			else
				ar1[i+1]=ar[i];
		}
		ar1[in]=el;
		return ar1;
	}
	static void dispArray(int ar[])
	{
		for (int i = 0; i < ar.length; i++) {
			System.out.print(ar[i]+" ");
		}
		
	}
}