import java.util.Scanner;


public class IsOctal {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number to validate :");
		int num=scan.nextInt();
		if(isOctal(num))
			System.out.println(num+" is Octal Number");
		else
			System.out.println(num+" is not a Octal Number ");
		scan.close();
	}

	static boolean isOctal(int n)
	{   
		while(n!=0)
		{
			int rem=n%10;
			//if(rem ==(0-7))
			if(rem<8)
			{	
			n=n/10;
			return true;
			}
			return false;
		}
		
	return false;
	}
}
