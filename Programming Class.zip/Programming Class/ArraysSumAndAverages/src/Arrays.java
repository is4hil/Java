
import java.util.Scanner;

public class Arrays {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Number of Elements ");
		int num=scan.nextInt();
		int ar[]=new int[num];
		System.out.println("Enter the Numbers: ");
		for(int i=0;i<ar.length;i++)
		{
			ar[i]=scan.nextInt();
		}
		int sum=0,avg=0;
		for(int i=0;i<ar.length;i++)
		{
			sum=sum+ar[i];
			avg=sum/ar.length ;
		}
		System.out.println("Sum of Number is: "+sum+" And Average of Number is: "+avg);
		scan.close();
	}
}
