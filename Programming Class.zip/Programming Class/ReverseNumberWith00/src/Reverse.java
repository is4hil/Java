import java.util.Scanner;
public class Reverse {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Your Number: ");
		Reverse rv=new Reverse();
		int num=scan.nextInt();
		String res=rv.getReverse(num);                 // we can access non Static method from static methods in two ways
		System.out.println("Reverse number is: "+res); //1.>Either by creating the object of Static class and calling the 
		scan.close();                                  // non-static method with help of created object
	}                                                  //Example>> Reverse rv=new Reverse();  
	 String getReverse(int n)                          //String res=rv.getReverse(num);
	{                                                  
		String rev="";							       
		while(n!=0)									
		{												//2.>Or directly declaring the method as static.
			int r=n%10;									//Example>> static String getReverse(int n)
			rev=rev+r;									//
			n=n/10;										//
		}
		return rev;
	}
}
/*OutPut
Enter Your NUmber: 
500000
Reverse number is: 000005
 */