
public class Arrays {
	
public static void main(String[] args) {
	int n=28;
	int ar[]= {34,16,5,43,23,46,12};
	for (int i = 0; i < ar.length-1; i++) {
		for (int j = i+1; j < ar.length; j++) {
			if(ar[i]+ar[j]==n)
			{
				System.out.println(ar[i]+" "+ar[j]);
				System.out.println("sum is "+(ar[i]+ar[j]));			
			}
			
		}
		
	}
	 
}
}
