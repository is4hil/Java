import java.util.Scanner;


public class HappyNumber {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Number :");
		int num=scan.nextInt();
		if(isHappy(num))
System.out.println(num+" is Happy Number.");
		else
			System.out.println(num+" is Not Happy Number.");
		scan.close();
	}
static boolean isHappy(int num)
{
	while(num>9)
	{
		int sum=0;
		while(num!=0)
		{
			
			int r=num%10;
			sum=sum+r*r;
			num=num/10;
		}
		
		num=sum;
	}	
return num==1||num==7;

}

}
