import java.util.Scanner;


public class PrimeMunber {
	public static void main(String[] args) {


		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Your Number To Checck: ");
		int numb=scan.nextInt();
		boolean res =IsPrime(numb);
		if(res)
			System.out.println("Given Number is Prime Number");
		else
			System.out.println("Given Number is Prime Number");
		scan.close();
	}
	static boolean IsPrime(int n){
		int i=2;
		while(i<=n/2)
		{
			if(n%i==0)
				return false;
			i++;
		}


		return true;
	}
}