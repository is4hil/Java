
final public class Demo {
	private final int price=890;
	
	public int getPrice() {
		return price;
	}
	
	public static void main(String[] args) {
		Demo d = new Demo();
		//d.price=35;         //final cannot be changed
		System.out.println(d.getPrice());
	}
}

