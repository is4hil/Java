import java.util.Scanner;

public class SumODigitInString {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the Sentences: ");
		String st=sc.nextLine();
		int sum=0;
		char ch[]=st.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			if(ch[i]>='0'&&ch[i]<='9')
				sum=sum+(ch[i]-48);
			
		}
		System.out.println(sum);
	}
}
