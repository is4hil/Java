import java.util.Scanner;

public class EndsWith {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter The String s1 and s2 ");
	String s1=scan.nextLine();
	String s2=scan.nextLine();
	boolean res=endsWith(s1,s2);
	if(res)
	{
		System.out.println("Ends with");
	}
	else
		System.out.println("Does not Ends with");
}

public static boolean endsWith(String s1, String s2)
{
	char ch1[]=s1.toCharArray();
	char ch2[]=s2.toCharArray();
	int i=ch1.length-1;
	int j=ch2.length-1;
	while(i>=0&&j>=0&&ch1[i]==ch2[j])
	{
		i--;
		j--;
	}
	return j==-1;
}
}
