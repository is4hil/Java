import java.util.Scanner;

public class Panagram {
public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter the Sentences: ");
	String st=sc.nextLine();
	//st=st.toUpperCase();
	st=toUpperCase(st);
	int c[]=new int[26];
	char ch[]=st.toCharArray();
	for (int i = 0; i < ch.length; i++) {
		if(ch[i]>=65&&ch[i]<=90)
			c[ch[i]-65]++;
		
	}
	for (int i = 0; i < ch.length; i++) {
		if(c[i]==0)
		{
			System.out.println("Sentence is not Panagram");
			return;
		}
	}
	System.out.println("Sentences Is Panagram");
	
}

public static String toUpperCase(String s) {
	for (int i = 0; i < s.length(); i++) {
		char ch[]=s.toCharArray();
		
	}
	
}

}
