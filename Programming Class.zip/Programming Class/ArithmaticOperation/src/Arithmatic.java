import java.util.Scanner;
public class Arithmatic {
	Scanner scan= new Scanner(System.in);
	//System.out.println("Enter the 1st Number:");
	double a=scan.nextDouble();
	//System.out.println("Enter the 2nd Number:");
	double b=scan.nextDouble();


	public void sum() {
		double sum=a+b;
		System.out.println("The Sum of two number is:"+sum);
	}
	public void sub() {
		double sub=a-b;
		System.out.println("The Subtraction of two number is:"+sub);
	}
	public void mul() {
		double mul=a*b;
		System.out.println("The Multiplication of two number is:"+mul);
	}
	public void div() {
		double div=a/b;
		System.out.println("The Division of two number is:"+div);
	}
	public static void main(String[] args) {

		{	
			Arithmatic arth=new Arithmatic();
			arth.sum();
			arth.sub();
			arth.div();
			arth.mul();
		}
	}
	//scan.close();
}

