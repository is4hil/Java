import java.util.Scanner;
public class HexToBin {
public static void main(String[] args) {
	Scanner scan =new Scanner(System.in);
	System.out.println("Enter the Hexa Decimal Number :");
	String num=scan.nextLine();
	int dec=hexaToDec(num);
	String bin= decToBin(dec);
	
	System.out.println("Decimal Number is number is: "+dec);
	System.out.println("Binary Number is number is: "+bin);
	scan.close();
}


static int hexaToDec(String s1)
{
	
int sum=0,p=0;
for(int i=s1.length()-1;i>=0;i--,p++)
{
char ch=s1.charAt(i);	
if(ch>='A' && ch<='F')
	sum=sum+(ch-55)*pow(16,p);
else if(ch>='a' && ch<='f')
	sum=sum+(ch-87)*pow(16,p);
else 
	sum=sum+(ch-48)*pow(16,p);
}
return sum;
}

static String decToBin(int n)
{
	   String bin="";
	   while(n>0)
	   {
		   int r=n%2;
		   bin=r+bin;
		   n=n/2;
	   }
	   return bin;
}


static int pow(int n,int p)
{
	int pw=1;
	while(p>0)
	{
		pw=pw*n;  
		p--;
	}
	return pw;
}

static String decToOct(int n)
{
	   String oct="";
	   while(n>0)
	   {
		   int r=n%8;
		   oct=r+oct;
		   n=n/8;
	   }
	   return oct;
}
}
