
public class Arrays {
public static void main(String[] args) {
	int ar1[]= {1,2,3,4,5};
	int ar2[]= {2,3,5,6,7};
	comElement(ar1,ar2);
	
}
static void comElement(int ar1[],int ar2[])
{
	for (int i = 0; i < ar1.length; i++) 
	{
		for (int j = 0; j < ar2.length; j++) 
		{
			if(ar1[i]==ar2[j])
				System.out.print("The commonn element in both arrays are:"+ar2[j]);
		}
	}
}
}
