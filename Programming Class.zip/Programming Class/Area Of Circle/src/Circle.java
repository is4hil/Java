
public class Circle {
	/*final double PI=3.14;
double r=4.5;
double a= PI*r*r;
void areaOfCircle()
{System.out.println("Area of Cicle is "+ a);*/

	public static void main(String[] args) {
		final double PI=3.14;
		double r=4.5;
		double a= PI*r*r;
		//void areaOfCircle()
		System.out.println("Area of Cicle is "+ a);
		/*Circle c= new Circle();
	c.areaOfCircle();}*/

	}
}