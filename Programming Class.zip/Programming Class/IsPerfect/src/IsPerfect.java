import java.util.Scanner;
public class IsPerfect {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Your Number: ");
		int num=scan.nextInt();
		boolean rs=IsPerf(num);
		if(rs)
			System.out.println(num+" is perfect Number");
		else
			System.out.println(num+" is not a perfect Number" );
		scan.close();
		
}

	 static boolean IsPerf(int n) {
		int i=1,sum=0;
		while(i<=n/2)
		{
			if(n%i==0)
			{
				sum=sum+i;
			}
			i++;
			//return true;
		}
		return false;
	}
	}