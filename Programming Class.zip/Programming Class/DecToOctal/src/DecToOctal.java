import java.util.Scanner;


public class DecToOctal {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Decimal Number To Convert: ");
		int num=scan.nextInt();
		String oct=decToOct(num);
		System.out.println("The Equivalent Binary Number of Octal Number "+num+" is -->"+oct);
		scan.close();
}
   static String decToOct(int n)
   {
	   String oct="";
	   while(n>0)
	   {
		   int r=n%8;
		   oct=r+oct;
		   n=n/8;
	   }
	   return oct;
   }
}