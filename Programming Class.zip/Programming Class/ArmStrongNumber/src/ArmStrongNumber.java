import java.util.Scanner;


public class ArmStrongNumber {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter ethe Number to Check : ");
		int no=scan.nextInt();
		int t=no;
		int c=getCount(no);
		int sum=0;
		while(no!=0)
		{
			int r=no%10;
			sum=sum+pow(r,c);
			no=no/10;
		}
		if(sum==t)
			System.out.println(t+" is Armstrong Number");
		else
			System.out.println(t+" is Not a Armstrong Number");
		scan.close(); 
	}
	static int getCount(int num)
	{
		int c=0;
		while(num!=0)
		{
			c++;
			num=num/10;
		}
		return c;
	}

	static int pow(int n,int p)
	{
		int pw=1;
		while(p>0)
		{
			pw=pw*n;
			p--;
		}
		return pw;
	}
}