import java.util.Scanner;
public class PerfectNumber {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Your Number: ");
		int num=scan.nextInt();
		int i=1,sum=0;
		while(i<=num/2)
		{
			if(num%i==0)
			{
				sum=sum+i;
			}
			i++;
		}
		if(sum==num)
			System.out.println("Perfect Number");
		else
			System.out.println("Not A perfect Number");
		scan.close();
	}


}	