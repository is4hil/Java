import java.util.Scanner;

public class Array {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the Number of Number ");
	int num=scan.nextInt();
	int ar[]=new int[num];
	System.out.println("Enter those Numbers: ");
	for(int i=0;i<ar.length;i++)
	{
		ar[i]=scan.nextInt();
	}
	int td=0;
	for(int i=0;i<ar.length;i++)
	{
		if(ar[i]>9&&ar[i]<100||ar[i]<-9&&ar[i]>-100)
			td++;
	}
	System.out.println("Two digit Number are: "+td);
	scan.close();
	}
}
