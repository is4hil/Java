import java.util.Scanner;

public class SplitWord {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter The Sentence which you want to split:");
	String senten=scan.nextLine();
	String[] splitWords=senten.split("\\S");
	for(String w:splitWords)
	{
		System.out.println(w);
	}
	scan.close();
}
}
