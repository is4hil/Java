import java.util.Scanner;


public class Swap {
	
	
		
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the Sentences: ");
		String s=scan.nextLine();
		s=swap(s);
		System.out.println(s);
		scan.close();
}
	static String swap(String s)
	{
		char ch[]=s.toCharArray();
		
		for (int i = 0; i < ch.length; i++) 
		{   int f=i;
			if(i==0&&ch[i]!=' '||ch[i]!=' '&&ch[i-1]==' ')
			{
				f=i;
			}	
			
			while(i<ch.length&&ch[i]!=' ')i++;
			int l=i-1;
			char t=ch[f];
			ch[f]=ch[l];
			ch[l]=t;
		}
	
		// String s="";
		//s=s+ch[i];
			
s= new String(ch);		
				
	
		return s;
	}

	
}


	