
public class Arrays {
public static void main(String[] args) {
	int ar[]= {1,2,3,4,5,6};
	int big=ar[0]+ar[1];
	
	for (int i = 1; i < ar.length-1; i++) 
	{
	 if(ar[i]+ar[i+1]>big)
	 {
		 big=ar[i]+ar[i+1];
	 	 int index=i;
	 	 	
	 }
	}
	System.out.println("The Biggest sum of two continuous number is: "+big);
	//System.out.print(ar[index]+", "+ar[index+1]);
}
}
