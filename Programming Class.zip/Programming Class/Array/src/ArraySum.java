
public class ArraySum {
public static void main(String[] args) {
	double ar[]=new double[4];
	ar[0]=1.5;
	ar[1]=2.5;
	ar[2]=3.5;
	ar[3]=4.5;
	double sum=ar[0]+ar[1]+ar[2]+ar[3];
	System.out.println(sum);
	
}
}
