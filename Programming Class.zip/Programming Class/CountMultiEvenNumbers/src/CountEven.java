import java.util.Scanner;
public class CountEven {
	public int getEven(int num) {
		int count=0;
		do {
			int rem=num%10;
			if (rem%2==0) 
				count++;
			num=num/10;

		} while (num!=0);
		return count;
	}
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);

		System.out.println("Enter The Number: ");
		int numb=scan.nextInt();
		CountEven c=new CountEven();
		int result=c.getEven(numb);
		System.out.println("The Number of Even Number are:"+result);

		System.out.println("Enter The Number: ");
		int numb1=scan.nextInt();
		CountEven c1=new CountEven();
		int result1=c1.getEven(numb1);
		System.out.println("The Number of Even Number are:"+result1);
		scan.close();
	}
}
