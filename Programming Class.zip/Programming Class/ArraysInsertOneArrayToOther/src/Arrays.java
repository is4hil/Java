import java.util.Scanner;



public class Arrays {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the 1st Array: ");
		int ar1[]=readArray();
		System.out.println("Enterr The 2nd Arrray: ");
		int ar2[]=readArray();
		System.out.println("Enter the Index");
		int in=scan.nextInt();
		int rs[]=add(ar1,ar2,in);
		System.out.println("After combine: ");
		dispArray(rs);
		scan.close();
	}
	 static int [] readArray()
	{
		 
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Number of Elements ");
		int num=scan.nextInt();
		int ar[]=new int[num];
		System.out.println("Enter the Numbers: ");
		for(int i=0;i<ar.length;i++)
		{
			ar[i]=scan.nextInt();
		}
		scan.close();
		return ar;
		
	}
	
	static void dispArray(int ar[])
	{
		for(int i=0;i<ar.length;i++)
		{
			System.out.print(ar[i]+" ");
		}
		System.out.println();
	}
	
	static int[] add(int s[],int d[],int in)
	{
		if(in<0||in>d.length)
			{
			System.out.println("Invalid Index");
			System.exit(0);
			}
		int rs[]= new int[s.length+d.length];
		for(int i=0;i<d.length;i++)
		{
			if(i<in)
				rs[i]=d[i];
			else
				rs[s.length+1]=d[i];
			
		}
		for(int i=0;i<s.length;i++)
		{
			rs[in+i]=s[i];
		}
		return rs;
		
		}
				
	}
	
	
