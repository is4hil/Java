package com.google.gmail;

import java.util.Random;

public class Rand
{
	Random r=new Random();
	
	Object 
}
