//Write a Java program to print the area and perimeter of a circle.
import java.util.Scanner;
public class Circle {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Radius");
		double radius=scan.nextDouble();
		final double PI=3.14;
		double area=PI*radius*radius;
		double perimeter=2*PI*radius;
		System.out.println("Area of Circle is: "+area);
		System.out.println("Perimeter of Circle is: "+perimeter);
		scan.close();
	}
}
