/*Write a Java program to convert a decimal number to hexadecimal number.
 Input :
 decimal number: 15
 Output
 Hexadecimal number is : F
*/
import java.util.Scanner;
public class DecimalToHexa {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Decimal Number: ");
		int d=scan.nextInt();
		System.out.printf("%X",d);
		scan.close();
		
	}

}
