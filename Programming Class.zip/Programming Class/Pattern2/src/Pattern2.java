import java.util.Scanner;


public class Pattern2 {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter How Many Number Yo Want");
	int num=scan.nextInt();
	int x=1;
	for(int i=1;i<=num;i++)
		{
		System.out.println(x+" ");
	     x=x+i;
	     }
}
}
