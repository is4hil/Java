
public class Arrays {
	public static void main(String[] args) {
		int ar[]= {34,56,78,34,34,18,34,56,12};
		int res[]=getUniqueElement(ar);
		for (int i = 0; i < res.length; i++) {
			System.out.print(res[i]+" ");
		}
	}



	static int[] getUniqueElement(int ar[])
	{
		for (int i = 0; i < ar.length;i++)
		{

			for (int j = i+1; j < ar.length; j++)
			{
				if(ar[i]==ar[j])
				{

					ar=delArray(ar,j);
					j--;

				}

			}
		}
		return ar;
	}
	static int[] delArray(int ar[],int index) {

		int ar1[]=new int[ar.length-1];
		for(int i=0;i<ar1.length;i++)
		{
			if(i<index)
				ar1[i]=ar[i];
			else
				ar1[i]=ar[i+1];
		}
		return ar1;
	}



}
