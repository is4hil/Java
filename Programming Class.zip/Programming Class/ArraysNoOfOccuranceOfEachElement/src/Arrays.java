
public class Arrays {
public static void main(String[] args) {
	int ar[]= {34,56,78,34,34,18,34,56,12};
	//int ar[]= {'a','b','d','a'};
	for (int i = 0; i < ar.length;i++)
	{
	int c=1;
	for (int j = i+1; j < ar.length; j++)
	{
	if(ar[i]==ar[j])
	{
		c++;
		ar=delArray(ar,j);
		j--;
	}
	}
	System.out.println(ar[i]+"-------------->"+c);
	}
}


static int[] delArray(int ar[],int index) {
	
	int ar1[]=new int[ar.length-1];
	 for(int i=0;i<ar1.length;i++)
	{
		if(i<index)
			ar1[i]=ar[i];
		else
			ar1[i]=ar[i+1];
	}
	 return ar1;
}

	
	
}
