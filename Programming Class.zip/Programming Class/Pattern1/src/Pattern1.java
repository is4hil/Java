
public class Pattern1 {
public static void main(String[] args) {
	int p=3;
	int n=5;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=p;j++)
			System.out.println(i+" "+j);
	}
}
}
