
public class Array {
public static void main(String[] args) {
	int ar[]= {1,2,3,4,5,6,7,8,9,10};
	int e=0,o=0;
	System.out.println("Number of elements in Array: "+ar.length);
	for(int i=1;i<=ar.length+1;i++)
	{
		if(ar[i]%2==0)
		 e++;  
		else
			o++;
			
		
	}
	System.out.println("Number of Even elements "+e);
	System.out.println("Number of Odd Elements "+o);
}
}
