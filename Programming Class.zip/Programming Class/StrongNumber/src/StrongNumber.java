import java.util.Scanner;


public class StrongNumber {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the Number: ");
	int num=scan.nextInt();
	boolean res= isStrong(num);
	if(res)
	System.out.println(num+" is Strong Number");
	else
		System.out.println(num+" is Not Strong Number");
	scan.close();
}

static boolean isStrong(int x)
{ 
	int sum=0,temp=x;
	while(x!=0)
	{
		int r=x%10;
		sum=sum+fact(r);    // since fact() method is called by isStrong() method and isStrong() method is called by main()
		x=x/10;             // method,in which main() method is static method so in turn all the methods must be static
	}                       // In simple we can say that , when static method calls d other method,it must b static..
	return temp==sum;       // Or else non static method can be called by using d object of static method.
}
 static int fact(int n)
{
int f=1;
while(n>0)
{
f=f*n;
n--;
}
return f;
}

}
