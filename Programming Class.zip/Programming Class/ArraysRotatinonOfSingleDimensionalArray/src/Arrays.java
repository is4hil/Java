
public class Arrays {
public static void main(String[] args) {
	int ar[]= {25,42,56,78,90,12};
	int pos=1;
	rightrotArray(ar,pos);
	for (int i = 0; i < ar.length; i++) 
	{
	 System.out.print(ar[i]+" ");	
	}
	System.out.println();
	leftrotArray(ar,pos);
	for (int i = 0; i < ar.length; i++) 
	{
	
	 System.out.print(ar[i]+" ");	
	}
	
}

static void rightrotArray(int ar[],int pos)
{
	while(pos>0)
	{
		int t=ar[ar.length-1];
				for (int i = 1; i < ar.length; i++) 
				{
				 int t1=ar[i-1]	;
				 ar[i-1]=t;
				 t=t1;
				}
				pos--;
	}
	int t=ar[0];
	for (int i = 1; i < ar.length; i++) {
		ar[i-1]=ar[i];
	}
	ar[ar.length-1]=t;
}

static void leftrotArray(int ar[],int pos)
{
	while(pos>0)
	{
		int t=ar[0];
				for (int i = 0; i < ar.length-1; i++) 
				{
					ar[i]=ar[i+1];
					ar[ar.length-1]=t;
				}
				pos--;
	}
}



}
