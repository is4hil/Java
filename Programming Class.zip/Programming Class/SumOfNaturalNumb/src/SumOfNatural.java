import java.util.Scanner;
public class SumOfNatural {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Your Number:" );
		int s=scan.nextInt();
		int sum=0;
		for(int i=1;i<=s;i++)
		{   
			sum=sum+i;
		}
			System.out.println(sum);
			scan.close();		
        }

}