import java.util.Scanner;

public class ReverseNumber {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Your Number: ");
		ReverseNumber rv=new ReverseNumber();
		int num=scan.nextInt();
		int res=rv.getReverse(num);
		System.out.println("Reverse number is: "+res);
		scan.close();
	}


	int getReverse(int n)
	{
		int rev=0;
		while(n!=0)
		{
			int r=n%10;
			rev=rev*10+r;
			n=n/10;
		}
		return rev;
	}
}
