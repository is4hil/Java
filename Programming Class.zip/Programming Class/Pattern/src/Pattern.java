
public class Pattern {
public static void main(String[] args) {
	/*int n=5;
	for(int i=1;i<=n; i++)
	{
		for(int j=1; j<=n-i;j++)
		{
			System.out.print(" ");
			
		}
		for (int j=1; j<=i;j++)
		{
			System.out.print("*");
		}
		
		System.out.println();
	}
	
	
	
	for(int i=1;i<=n; i++)
	{
		for(int j=1; j<=n-i;j++)
		{
			System.out.print(" ");
			
		}
		for (int j=1; j<=i;j++)
		{
			System.out.print(j+"");
		}
		
		System.out.println();
	}
	
	
	for(int i=1;i<=n; i++)
	{
		for(int j=1; j<=n-i;j++)
		{
			System.out.print(" ");
			
		}
		for (int j=1; j<=i;j++)
		{
			System.out.print((char)(j+64)+"");
		}
		
		System.out.println();
	}
	
	for(int i=1;i<=n; i++)
	{
		for(int j=1; j<=n-i;j++)
		{
			System.out.print(" ");
			
		}
		for (int j=1; j<=i;j++)
		{
			System.out.print((char)(i+64)+"");
		}
		
		System.out.println();
	}
	
	for(int i=1;i<=n; i++)
	{
		for(int j=1; j<=i-1;j++)
		{
			System.out.print(" ");
			
		}
		for (int j=1; j<=n-i+1;j++)
		{
			System.out.print(j+"");
		}
		
		System.out.println();
	}
	
	for(int i=1;i<=n; i++)
	{
		for(int j=1; j<=n-i;j++)
		{
			System.out.print("  ");
			
		}
		for (int j=1; j<=2*i-1;j++)
		{
			System.out.print("* ");
		}
		
		System.out.println();
	}
	
	
	for(int i=1;i<=n; i++)
	{
		for(int j=1; j<=n-i;j++)
		{
			System.out.print("  ");
			
		}
		for (int j=1; j<=2*i-1;j++)
			if(j%2!=0)
			{
				System.out.print(j/2+1+" ");
			}
			else
		{
			System.out.print("* ");
		}
		
		System.out.println();
	}
	
	for(int i=1;i<=n; i++)
	{
		for(int j=1; j<=n-i;j++)
		{
			System.out.print("  ");
			
		}
		int k=1;
		for (int j=1; j<=2*i-1;j++)
		{			
				System.out.print(k+" ");
				if(j<i)
					k++;
				else
					k--;
		}
		System.out.println();
	}
	
	int n=7,sp=n/2,st=1;
	for(int i=1;i<=n ;i++)
	{
		for(int j=1;j<=n;j++)
			{
			System.out.print("  ");
			}
		for(int j=1;j<=st;j++);
			{
				System.out.println("* ");
			}
		if(i<=n/2)
			{
			st=st+2;
			sp--;
			}
		else
		{
			st=st-2;
			sp++;
		
		}
	}
	System.out.println();
	
	
	
	
	
	int n=9,sp=n/2,st=1;
	for(int i=1;i<=n ;i++)
	{
		for(int j=1;j<=sp;j++)
			{
			System.out.print("  ");
			}
		
		for(int j=1;j<=st;j++)
		{
			if(j%2==0)
				System.out.print("* ");
			else
				System.out.print(j/2+1+" ");
		}
		if(i<=n/2)
			{
			st=st+2;
			sp--;
			}
		else
		{
			st=st-2;
			sp++;
		}
		System.out.println();
		}
	
	
	
	
	
	}
}
	
	
	
	
	/*int n=7,sp=n/2,st=1;
	for(int i=1;i<=n ;i++)
	{
		for(int j=1;j<=sp;j++)
			{
			System.out.print("  ");
			}
		int k=1;
		for(int j=1;j<=st;j++);
			{
				System.out.print(k+" ");
			}
		if(i<=n/2)
			{
			st=st+2;
			sp--;
			}
		else
		{
			st=st-2;
			sp++;
		}
		}
	
int n=7,sp=n/2,st=1;
for(int i=1;i<=n ;i++)
{
	for(int j=1;j<=sp;j++)
		{
		System.out.print("  ");
		}
	int k=1;
	for(int j=1;j<=st;j++);
		{
			System.out.print(k+" ");
		}
	if(i<=n/2)
		{
		st=st+2;
		sp--;
		}
	else
	{
		st=st-2;
		sp++;
	}
	}


 int n=15;
 for(int i=1;i<=n;i++)
 {
	 for(int j=1;j<=n;j++)
	 {
		 if(i==1||i==n||j==1||j==n||i==j||i+j==n+1)
			 System.out.print("*");
		 else
			 System.out.print(" ");
	 }
	 System.out.println();
	 
 }

 int n=15;
 for(int i=1;i<=n;i++)
 {
	 for(int j=1;j<=n;j++)
	 {
		 if(i==1||i==n||j==1||j==n||i==n/2+1||j==n/2+1)
			 System.out.print("*");
		 else
			 System.out.print(" ");
	 }
	 System.out.println();
	 
 }
 
 
 int n=9;
 for(int i=1;i<=n;i++)
 {
	 for(int j=1;j<=n;j++)
	 {
		 if(i==1||i==n||j==1||j==n||i==j)
			 System.out.print("*");
		 else
			 System.out.print(" ");
	 }
	 System.out.println();
	 
 }
 
 
 int n=17;
 int st=1,sp=n/2;
 for(int i=1;i<=n;i++)
 {  
	 for(int j=1;j<=sp;j++)
	 {
		 System.out.print("  ");
	 }
	 for (int j = 1; j <=st; j++) 
	 {
		System.out.print("* ");
	 }
	 if(i<=n/2)
	 {
		 st=st+2;
		 sp--;
	 }
	 else
	 {
		 st=st-2;
		 sp++;
	 }
	System.out.println();
	
}

	String st ="AbibA";
	for(int i=0;i<st.length();i++)
	{
		for(int j=0;j<st.length();j++)
		{
			if(i==0||i==st.length()-1)
				System.out.print(st.charAt(j)+" ");
			else if(j==0||j==st.length()-1)
				System.out.print(st.charAt(i)+" ");
			else
				System.out.print(" ");
			
				
		}
	
	System.out.println();
	}

	 int n=9;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n;j++)
		 {
			 if(j==1||j==n||i==j||i+j==n+1)
				 System.out.print("*");
			 else
				 System.out.print(" ");
		 }
		 System.out.println();
		 
	 }
	 
	 int n=9;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n;j++)
		 {
			 if(j==1||j==n||(i==j||i+j==n+1)&&i<=n/2+1)
				 System.out.print("*");
			 else
				 System.out.print(" ");
		 }
		 System.out.println();
		 
	 }
	 

	int n=9;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n;j++)
		 {
			 if(j==1||j==n||(i==j||i+j==n+1)&&i>=n/2+1)
				 System.out.print("*");
			 else
				 System.out.print(" ");
		 }
		 System.out.println();
		 
	 }
	
	int n=9;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n/2;j++)
		 {
			 if(j==n/2+1||i==j||i+j==n+1)
				 System.out.print("*");
			 else
				 System.out.print(" ");
		 }
		 System.out.println();
		 
	 }
	
	int n=7;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n/2;j++)
		 {
			 if(j==1||i==0||i==n/2+1||i==1||i==n)
				 System.out.print("*");
			 else
				 System.out.print(" ");
		 }
		 System.out.println();
		 
	 }
	
	int n=7;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n;j++)
		 {
			 if((j==0||(i==1||i==n)&&j<=n/2||(j==n/2||j==n)&&i>=n/2||i==n/2&&j>=n/2))
				 System.out.print("*");
			 else
				 System.out.print(" ");
		 }
		 System.out.println();
		 
	 }
	
	
	int n=7;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n;j++)
		 {
			 if(j==1||j==n/2+1||(i==n/2+1)&&(j<=n/2+1))
				 System.out.print("* ");
			 else
				 System.out.print("  ");
		 }
		 System.out.println();
		 
	 }
	 
	 
	 
	 
	 int n=7;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n;j++)
		 {
			 if(i==1||i==n||j==n/2+1)
				 System.out.print("* ");
			 else
				 System.out.print("  ");
		 }
		 System.out.println();
		 
	 }
	
	
	
	 int n=7;
	 for(int i=1;i<=n;i++)
	 {
		 for(int j=1;j<=n;j++)
		 {
			 if(i==1||(i==n)&&)
				 System.out.print("* ");
			 else
				 System.out.print("  ");
		 }
		 System.out.println();
		 
	 }
	*/
	
	
	int n=7;
	 for(int i=0;i<n;i++)
	 {
		 for(int j=0;j<n;j++)
		 {
			 if(i==j&&i>=n/2||(j==0||j==3*n/4)&&i<=3*n/4|(i==0||i==3*n/4)&&j<=3*n/4)
				 System.out.print("* ");
			 else
				 System.out.print("  ");
		 }
		 System.out.println();
		 
	 }
}
}

