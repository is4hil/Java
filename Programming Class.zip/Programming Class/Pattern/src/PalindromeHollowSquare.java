
public class PalindromeHollowSquare {
	public static void main(String[] args) {
		String st="AsiA";                                                      //a n a   A s i A 
				for(int i=1;i<=st.length();i++)                                //n   n   s     s
				{                                                              //a n a   i     i
					for(int j=1;j<=st.length();j++)                            //        A s i A
					{                                                          //      
						if(i==1||i==st.length())
						System.out.print(st.charAt(j-1)+" ");
						
																										//So should begin and end with A
							else if(j==1||j==st.length())
							System.out.print(st.charAt(i-1)+" ");
						else
							System.out.print("  ");
					}
					System.out.println();
				}		
	}

}
