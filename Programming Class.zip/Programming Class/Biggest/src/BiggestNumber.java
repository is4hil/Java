
public class BiggestNumber {
	int getBiggest(int a,int b,int c)
	{
		if(a>=b&&a>=c)
			return a;
		else if(b>=c)
			return b;
		else 
			return c;
	}
	public static void main(String[] args) {
		BiggestNumber big=new BiggestNumber();
		int b1=big.getBiggest(30,40,60);
		System.out.println("Biggest Number is "+b1);

	}
}
