import java.util.Random;

public class Shop  {
	
 public Vegetable  Sell()
{
	Random r=new  Random();
	int num=r.nextInt(3);
	if(num==0)
		return new Carrot();
	else if(num==1)
		return  new Potato();
	else
		return new Chilli();
	
}
}
