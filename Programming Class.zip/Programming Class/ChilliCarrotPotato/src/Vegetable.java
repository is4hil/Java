
public class Vegetable {
void varity()
{
	System.out.println("Varity of Vegetables");
}
}
