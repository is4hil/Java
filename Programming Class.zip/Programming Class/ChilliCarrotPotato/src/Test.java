
public class Test {
	public static void main(String[] args) {
		System.out.println("Started Preparing");
Shop s= new Shop();

Vegetable v=s.Sell();
if(v instanceof Potato )
	{
	Potato p= (Potato)v;
	p.prepareWafer();
	}

if(v instanceof Carrot )
{
Carrot c= (Carrot)v;
c.prepareHalwa();
}

if(v instanceof Chilli )
{
Chilli c= (Chilli)v;
c.prepareBajji();
}
System.out.println("Prepared Completely");
	}
}