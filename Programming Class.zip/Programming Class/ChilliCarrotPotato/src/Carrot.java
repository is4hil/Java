
public class Carrot extends Vegetable {
void prepareHalwa()
{
	System.out.println("Halwa");
}
}
