
public class Potato extends Vegetable {
void prepareWafer()
{
System.out.println("Wafer");	
}
}
