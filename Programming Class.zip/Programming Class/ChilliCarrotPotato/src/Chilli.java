
public class Chilli extends Vegetable {
void prepareBajji()
{
	System.out.println("Bajji");
}
}
