
public class Bomb extends Weapons {
	void takeBomb()
	{
		System.out.println("Bomb Taken");
	}

}
