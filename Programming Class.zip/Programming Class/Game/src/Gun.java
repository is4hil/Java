
public class Gun extends Weapons {
	void TakeGun()
	{
		System.out.println("Gun Taken");
	}

}
