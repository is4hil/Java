
public class Knife extends  Weapons {
void takeKnife()
{
	System.out.println("Knife Taken");
}
}
