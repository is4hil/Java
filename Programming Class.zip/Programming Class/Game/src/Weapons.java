
public class Weapons {

}
