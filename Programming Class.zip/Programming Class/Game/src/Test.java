
public class Test {
public static void main(String[] args) {
	System.out.println("App Started");
	
	Option o=new Option();
	Weapons wp=o.select();//upcasting
	System.out.println(wp);
	
	if(wp instanceof Gun)
	{
		Gun g= (Gun)wp;// downCasting
		g.TakeGun();
	}
	
	else if(wp instanceof Bomb)
	{
		Bomb b= (Bomb)wp;// downCasting
		b.takeBomb();
	}
	
	else
	{
		Knife k= (Knife)wp;// downCasting
		k.takeKnife();
	}
	System.out.println("App Ended");
}
}
