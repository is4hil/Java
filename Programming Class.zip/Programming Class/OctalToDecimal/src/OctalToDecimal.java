/*Write a Java program to convert a octal number to a decimal number.
input :
octal number: 10 
Output
Equivalent decimal number: 8
*/
import java.util.Scanner;
public class OctalToDecimal {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The Octal Number: ");
		int o=scan.nextInt();
		System.out.println(o);
		scan.close();

	}

}